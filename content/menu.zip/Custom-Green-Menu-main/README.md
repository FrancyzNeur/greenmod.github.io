# Custom-green-menu
Hi! 
This is a Custom-Green-Edition menu for garry's mod. 
This project is based on other projects

Thank you, 2 people who helped me

How to download? LINK - https://clck.ru/xzvFX

![image](https://user-images.githubusercontent.com/68936761/188503034-85c658cd-041f-462e-95c8-66fba93c54d6.png)

✨𝙒𝙚𝙡𝙘𝙤𝙢𝙚 𝙩𝙤 𝙢𝙮 𝙥𝙧𝙤𝙛𝙞𝙡𝙚! 𝙎𝙚𝙩𝙩𝙡𝙚 𝙙𝙤𝙬𝙣.✨

🌱 1. 𝙔𝙤𝙪𝙏𝙪𝙗𝙚 - https://vk.cc/caFS5b

👯 2. 𝙎𝙩𝙚𝙖𝙢 - https://vk.cc/caFSbF

💞️ 3. 𝘿𝙞𝙨𝙘𝙤𝙧𝙙 - https://vk.cc/caFSJh

💬 4. 𝙏𝙚𝙡𝙚𝙜𝙧𝙖𝙢 - https://vk.cc/cgkfFC

⚡𝙏𝙝𝙚𝙧𝙚'𝙨 𝙖 𝙡𝙤𝙩 𝙤𝙛 𝙛𝙪𝙘𝙠𝙞𝙣𝙜 𝙞𝙣𝙩𝙚𝙧𝙚𝙨𝙩𝙞𝙣𝙜 𝙨𝙩𝙪𝙛𝙛 𝙞𝙣 𝙝𝙚𝙧𝙚.
